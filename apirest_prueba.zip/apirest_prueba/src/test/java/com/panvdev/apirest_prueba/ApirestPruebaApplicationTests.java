package com.panvdev.apirest_prueba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApirestPruebaApplicationTests {

	@Test
	void contextLoads() {
	}

}
